module com.alexia.polimorfismo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.alexia.polimorfismo.models to javafx.base;
    opens com.alexia.polimorfismo to javafx.fxml;
    exports com.alexia.polimorfismo;
    exports com.alexia.polimorfismo.controllers;
    opens com.alexia.polimorfismo.controllers to javafx.fxml;
}