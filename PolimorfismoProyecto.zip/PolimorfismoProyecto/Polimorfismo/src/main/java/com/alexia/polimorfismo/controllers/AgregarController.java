package com.alexia.polimorfismo.controllers;

import com.alexia.polimorfismo.App;
import com.alexia.polimorfismo.models.Student;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class AgregarController {

    @FXML
    private Button saveButton;

    @FXML
    private TextField textFieldMatricula;

    @FXML
    private TextField textFieldNombre;

    @FXML
    void onMouseClickedGuardar(MouseEvent event) {
        if (textFieldMatricula.getText().trim().isEmpty() ||textFieldNombre.getText().trim().isEmpty()) {
            Alert alert=new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setContentText("Los campos están vacíos");
            alert.showAndWait();
        }else {
            try {
                int matricula = Integer.parseInt(textFieldMatricula.getText());
                String nombre = textFieldNombre.getText();
                Student student = new Student(matricula, nombre);
                if (App.getBases().addStudent(student)) {
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Notificación");
                    alert.setContentText("Datos agregados correctamente.");
                    alert.showAndWait();
                }else {
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Error");
                    alert.setContentText("No se puede agregar intente de nuevamente");
                    alert.showAndWait();
                }
            }catch (Exception e){
                Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Error");
                alert.setContentText("Solo se puede ingresar números en la matrícula: "+e.getMessage());
                alert.showAndWait();
            }
        }
    }

}