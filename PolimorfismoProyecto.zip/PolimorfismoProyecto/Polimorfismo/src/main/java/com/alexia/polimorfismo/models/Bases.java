package com.alexia.polimorfismo.models;

import java.util.ArrayList;

public class Bases {
    private ISudent estudiantesBase1 = new BaseDeDatos1();
    private ISudent estudiantesBase2 = new BaseDeDatos2();
    private ISudent estudiantesBase3 = new BaseDeDatos3();

    public boolean addStudent(Student newStudent) {
        boolean red;
        if (estudiantesBase1.save(newStudent) && estudiantesBase2.save(newStudent) &&  estudiantesBase3.save(newStudent)){
            System.out.println("RFelicidades el registro ha sido exitoso");
            red=true;
        }
        else {
            red=false;
            System.out.println("Error al registrar el registro");
        }
    return red;
    }
    public boolean updataStudent(Student editedStudent){
        boolean red=false;
        if (estudiantesBase1.upDate(editedStudent) && estudiantesBase2.upDate(editedStudent)&&estudiantesBase3.upDate(editedStudent)){
            red=true;
        }
        return red;
    }
    public ArrayList<Student> getStudentBase1(){
        return estudiantesBase1.getStudent();
    }
    public ArrayList<Student> getStudentBase2(){return estudiantesBase2.getStudent();}
    public ArrayList<Student> getStudentBase3(){return estudiantesBase3.getStudent();}
}
